//loadExternalJS("cordova.js", "cordova.js");
//loadExternalJS("index.js", "js/index.js");
//loadExternalJS("components/loader.js","components/loader.js");
//loadExternalJS("lib/onsenui/js/onsenui.min.js","lib/onsenui/js/onsenui.min.js");
loadExternalJS("1","js/camera.js");
loadExternalJS("2","js/position.js");
loadExternalJS("3","js/direction.js");
loadExternalJS("4","js/watchposition.js");
loadExternalJS("5", "js/dialog.js");
loadExternalJS("6", "js/accelerator.js");
loadExternalJS("8", "js/barcode.js");//not working
loadExternalJS("10", "js/global.js");
loadExternalJS("11", "js/contact.js");
loadExternalJS("12", "js/browser.js");
loadExternalJS("14", "js/corbarscan.js");//not working
