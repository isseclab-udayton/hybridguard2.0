//loadExternalJS("index.js", "js/index.js");

//loadExternalJS("framework7.min.js","js/framework7.min.js");

//loadExternalJS("my-app.js","js/my-app.js");

//loadExternalJS("cordova.js", "cordova.js");

loadExternalJS("1","js/plugins/camera.js");
loadExternalJS("2","js/plugins/position.js");
loadExternalJS("3","js/plugins/direction.js");
loadExternalJS("4","js/plugins/watchposition.js");
loadExternalJS("5", "js/plugins/dialog.js");
loadExternalJS("6", "js/plugins/accelerator.js");
loadExternalJS("8", "js/plugins/barcode.js");
loadExternalJS("10", "js/plugins/global.js");
loadExternalJS("11", "js/plugins/contact.js");
loadExternalJS("12", "js/plugins/browser.js");
loadExternalJS("14", "js/plugins/corbarscan.js");
