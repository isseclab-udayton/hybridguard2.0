//loadExternalJS("3","js/direction.js");
loadExternalJS("cordova.js", "cordova.js"); 