loadExternalJS("index.js","js/index.js");
//loadExternalJS("2","js/position.js");
//loadExternalJS("3","js/direction.js");
//loadExternalJS("4","js/watchposition.js");