//loadExternalJS("1","js/camera.js");
loadExternalJS("2","js/position.js");
//loadExternalJS("3","js/direction.js");
//loadExternalJS("4","js/watchposition.js");